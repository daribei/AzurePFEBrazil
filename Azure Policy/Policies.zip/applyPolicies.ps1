New-AzPolicyDefinition -Name 'auditorphanedpublicip' -DisplayName 'Audit Orphaned Public IP' -Metadata '{"category":"Cost Optimization"}' -Policy auditpublicipaddr.json

New-AzPolicyDefinition -Name 'auditorphanednic' -DisplayName 'Audit Orphaned Network Interface Card"' -Metadata '{"category":"Cost Optimization"}' -Policy auditorphanednic.json

New-AzPolicyDefinition -Name 'auditorphanedloadbalancer' -DisplayName 'Audit Orphaned Load Balancer' -Metadata '{"category":"Cost Optimization"}' -Policy auditorphanedloadbalancer.json

New-AzPolicyDefinition -Name 'auditorphaneddisks' -DisplayName 'Audit Orphaned Disks' -Metadata '{"category":"Cost Optimization"}' -Policy auditorphaneddisks.json

New-AzPolicyDefinition -Name 'auditorphanedavailabilityset' -DisplayName 'Audit Orphaned Availability Set' -Metadata '{"category":"Cost Optimization"}' -Policy auditorphanedavailabilityset.json

New-AzPolicyDefinition -Name 'auditorphanedapplicationgateway' -DisplayName 'Audit Orphaned Application Gateway' -Metadata '{"category":"Cost Optimization"}' -Policy auditorphanedapplicationgateway.json

	