$mgmtId = "<Root Group ID"

New-AzPolicyDefinition -Name 'auditorphanedpublicip' -DisplayName 'Audit Orphaned Public IP' -Metadata '{"category":"Cost Optimization"}' -Policy auditpublicipaddr.json -ManagementGroupName $mgmtId

New-AzPolicyDefinition -Name 'auditorphanednic' -DisplayName 'Audit Orphaned Network Interface Card"' -Metadata '{"category":"Cost Optimization"}' -Policy auditorphanednic.json -ManagementGroupName $mgmtId

New-AzPolicyDefinition -Name 'auditorphanedloadbalancer' -DisplayName 'Audit Orphaned Load Balancer' -Metadata '{"category":"Cost Optimization"}' -Policy auditorphanedloadbalancer.json -ManagementGroupName $mgmtId

New-AzPolicyDefinition -Name 'auditorphaneddisks' -DisplayName 'Audit Orphaned Disks' -Metadata '{"category":"Cost Optimization"}' -Policy auditorphaneddisks.json -ManagementGroupName $mgmtId

New-AzPolicyDefinition -Name 'auditorphanedapplicationgateway' -DisplayName 'Audit Orphaned Application Gateway' -Metadata '{"category":"Cost Optimization"}' -Policy auditorphanedapplicationgateway.json -ManagementGroupName $mgmtId